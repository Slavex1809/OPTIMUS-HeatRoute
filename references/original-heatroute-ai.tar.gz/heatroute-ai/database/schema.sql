CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TABLE IF NOT EXISTS calculation (id uuid PRIMARY KEY, created_at timestamptz NOT NULL DEFAULT now(), status text NOT NULL, source_filename text, result_geojson jsonb);
CREATE TABLE IF NOT EXISTS input_feature (id bigserial PRIMARY KEY, calculation_id uuid REFERENCES calculation(id) ON DELETE CASCADE, external_id text, object_type text, restriction_type text, diameter integer, flow_tph double precision, upstream_object_id text, oks_id text, geometry geometry(Geometry,32637), properties jsonb);
CREATE INDEX IF NOT EXISTS input_feature_gix ON input_feature USING gist(geometry);
CREATE INDEX IF NOT EXISTS input_feature_type_ix ON input_feature(object_type, restriction_type);
