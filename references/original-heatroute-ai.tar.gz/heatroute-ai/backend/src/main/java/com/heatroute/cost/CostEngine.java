package com.heatroute.cost;
import com.heatroute.hydraulic.EngineeringTable; import com.heatroute.model.Variant;
public final class CostEngine { public static double segment(double len,int d,double depth,double kSpecial){var r=EngineeringTable.byDiameter(d);double kg=depth<=3?1:1+0.10*(depth-3);return len*r.newCost*kg*kSpecial;} public static double score(Variant v){return .7*(v.calculatedCost()/25000000.0)+.3*(v.newLength+v.reconstructionLength)/100.0;} public static double penalty(double flow){return 100000000+500000*flow;} private CostEngine(){} }
