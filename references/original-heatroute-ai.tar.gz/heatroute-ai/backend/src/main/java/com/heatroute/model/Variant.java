package com.heatroute.model;
import org.locationtech.jts.geom.Geometry; import java.util.*;
public class Variant { public String id; public List<Map<String,Object>> features=new ArrayList<>(); public double constructionCost,chamberConstructionCost,tieInCost,reconstructionCost,chamberReconstructionCost,unconnectedPenalty,newLength,reconstructionLength,score; public List<String> unconnected=new ArrayList<>(); public double calculatedCost(){return constructionCost+chamberConstructionCost+tieInCost+reconstructionCost+chamberReconstructionCost+unconnectedPenalty;} }
