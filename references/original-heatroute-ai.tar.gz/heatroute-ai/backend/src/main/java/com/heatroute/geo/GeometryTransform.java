package com.heatroute.geo;
import org.locationtech.jts.geom.Geometry;
public final class GeometryTransform {private GeometryTransform(){} public static void forward(Geometry g){if(g==null)return;g.apply(c->{double[] p=Utm37.forward(c.x,c.y);c.x=p[0];c.y=p[1];});g.geometryChanged();}public static void inverse(Geometry g){if(g==null)return;g.apply(c->{double[] p=Utm37.inverse(c.x,c.y);c.x=p[0];c.y=p[1];});g.geometryChanged();}}
