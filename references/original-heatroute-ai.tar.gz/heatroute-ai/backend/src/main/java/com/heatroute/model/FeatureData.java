package com.heatroute.model;
import org.locationtech.jts.geom.Geometry; import java.util.*;
public class FeatureData { public String id, objectType, restrictionType, upstreamId, oksId; public Integer diameter; public Double flowTph, heatLoad; public Geometry geometry; public Map<String,Object> props=new LinkedHashMap<>(); }
